import { useState, useEffect, useRef } from 'react';
import { User, Study, Message } from '../types';
import { getStudyById, updateStudy, createStudy } from '../store';
import { agents, processAgentResponse, generateReport, getAgentCompletionMessage } from '../agents';

interface Props {
  user: User | null;
  studyId: string;
  isDemo: boolean;
  onBack: () => void;
  onComplete: (studyId: string) => void;
}

export default function StudyPage({ user, studyId, isDemo, onBack, onComplete }: Props) {
  const [study, setStudy] = useState<Study | null>(null);
  const [input, setInput] = useState('');
  const [currentAgent, setCurrentAgent] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let s: Study;
    if (isDemo) {
      s = {
        id: 'demo-' + Date.now(),
        userId: 'demo',
        userName: 'مستخدم تجريبي',
        projectName: 'مشروع تجريبي',
        status: 'in_progress',
        currentAgent: 0,
        createdAt: new Date().toISOString(),
        data: {},
        messages: [],
      };
    } else {
      const existing = getStudyById(studyId);
      if (existing) {
        s = existing;
        setCurrentAgent(existing.currentAgent);
        // Calculate the correct question index based on messages
        const agentMessages = existing.messages.filter(
          m => m.role === 'user' && m.agentIndex === existing.currentAgent
        );
        setCurrentQuestion(agentMessages.length);
      } else if (user) {
        s = createStudy(user.id, user.name);
      } else {
        return;
      }
    }
    setStudy(s);

    // Send first agent message if no messages
    if (s.messages.length === 0) {
      setTimeout(() => {
        const welcomeMsg: Message = {
          id: 'msg-' + Date.now(),
          role: 'agent',
          content: agents[0].questions[0],
          agentIndex: 0,
          timestamp: new Date().toISOString(),
        };
        s.messages.push(welcomeMsg);
        setStudy({ ...s });
        if (!isDemo) updateStudy(s);
      }, 500);
    }
  }, [studyId, isDemo]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [study?.messages.length, isTyping]);

  const sendMessage = () => {
    if (!input.trim() || !study || isTyping) return;

    // Demo limit - only first agent
    if (isDemo && currentAgent >= 1) {
      alert('النسخة التجريبية تتيح تجربة الوكيل الأول فقط. سجّل حسابك للوصول الكامل!');
      return;
    }

    const userMsg: Message = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: input.trim(),
      agentIndex: currentAgent,
      timestamp: new Date().toISOString(),
    };

    const updatedStudy = { ...study };
    updatedStudy.messages = [...study.messages, userMsg];

    // Process data
    updatedStudy.data = processAgentResponse(currentAgent, currentQuestion, input.trim(), updatedStudy.data);

    // Update project name if first question
    if (currentAgent === 0 && currentQuestion === 0) {
      updatedStudy.projectName = input.trim();
    }

    setStudy(updatedStudy);
    setInput('');
    setIsTyping(true);

    const agent = agents[currentAgent];
    const nextQ = currentQuestion + 1;

    setTimeout(() => {
      if (nextQ < agent.questions.length) {
        // Next question
        const agentMsg: Message = {
          id: 'msg-' + (Date.now() + 1),
          role: 'agent',
          content: agent.questions[nextQ],
          agentIndex: currentAgent,
          timestamp: new Date().toISOString(),
        };
        updatedStudy.messages = [...updatedStudy.messages, agentMsg];
        setCurrentQuestion(nextQ);
        setStudy({ ...updatedStudy });
        if (!isDemo) updateStudy(updatedStudy);
        setIsTyping(false);
        inputRef.current?.focus();
      } else {
        // Agent completed
        const completionMsg: Message = {
          id: 'msg-' + (Date.now() + 1),
          role: 'agent',
          content: getAgentCompletionMessage(currentAgent, updatedStudy.data),
          agentIndex: currentAgent,
          timestamp: new Date().toISOString(),
        };
        updatedStudy.messages = [...updatedStudy.messages, completionMsg];
        setStudy({ ...updatedStudy });
        if (!isDemo) updateStudy(updatedStudy);
        setIsTyping(false);

        const nextAgent = currentAgent + 1;
        if (nextAgent < agents.length) {
          // Move to next agent after a delay
          setTimeout(() => {
            setCurrentAgent(nextAgent);
            setCurrentQuestion(0);
            updatedStudy.currentAgent = nextAgent;

            if (nextAgent === 5) {
              // Report agent
              const reportContent = generateReport(updatedStudy.data);
              updatedStudy.report = reportContent;
            }

            const nextAgentMsg: Message = {
              id: 'msg-' + (Date.now() + 2),
              role: 'agent',
              content: agents[nextAgent].questions[0],
              agentIndex: nextAgent,
              timestamp: new Date().toISOString(),
            };
            updatedStudy.messages = [...updatedStudy.messages, nextAgentMsg];
            setStudy({ ...updatedStudy });
            if (!isDemo) updateStudy(updatedStudy);
            inputRef.current?.focus();
          }, 1500);
        }
      }
    }, 800 + Math.random() * 700);
  };

  const handleReportConfirm = () => {
    if (!study) return;

    const userMsg: Message = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: input.trim() || 'لا، متابعة إنشاء التقرير',
      agentIndex: 5,
      timestamp: new Date().toISOString(),
    };

    const updatedStudy = { ...study };
    updatedStudy.messages = [...study.messages, userMsg];
    updatedStudy.status = 'completed';
    updatedStudy.report = generateReport(updatedStudy.data);

    const finalMsg: Message = {
      id: 'msg-' + (Date.now() + 1),
      role: 'agent',
      content: getAgentCompletionMessage(5, updatedStudy.data),
      agentIndex: 5,
      timestamp: new Date().toISOString(),
    };
    updatedStudy.messages = [...updatedStudy.messages, finalMsg];

    setStudy(updatedStudy);
    if (!isDemo) updateStudy(updatedStudy);
    setInput('');

    setTimeout(() => {
      onComplete(updatedStudy.id);
    }, 2000);
  };

  if (!study) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4" />
        <p className="text-gray-500 font-semibold">جاري التحميل...</p>
      </div>
    </div>
  );

  const currentAgentInfo = agents[currentAgent];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 z-20">
        <div className="max-w-full mx-auto px-4">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center gap-3">
              <button onClick={onBack} className="px-3 py-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors text-sm font-semibold flex items-center gap-1">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                رجوع
              </button>
              <div className="h-6 w-px bg-gray-200" />
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-br from-[#1E3A8A] to-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">+</span>
                </div>
                <span className="text-lg font-bold text-gray-900 hidden sm:inline">{study.projectName}</span>
              </div>
              {isDemo && <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs font-bold">تجريبي</span>}
            </div>
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className="lg:hidden px-3 py-1.5 bg-gray-100 rounded-lg text-sm font-semibold flex items-center gap-1"
            >
              📋 المعلومات
            </button>
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 z-10">
        <div className="max-w-full mx-auto">
          <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-hide">
            {agents.map((agent, i) => (
              <div key={i} className="flex items-center flex-shrink-0">
                <div className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-semibold transition-all duration-300 ${
                  i === currentAgent ? `${agent.bgColor} ${agent.color} ring-2 ring-current shadow-sm` :
                  i < currentAgent ? 'bg-green-100 text-green-700' :
                  'bg-gray-100 text-gray-400'
                }`}>
                  <span className="text-base">{i < currentAgent ? '✓' : agent.icon}</span>
                  <span className="hidden sm:inline whitespace-nowrap">{agent.name}</span>
                  <span className="sm:hidden">{i + 1}</span>
                </div>
                {i < agents.length - 1 && (
                  <div className={`w-4 sm:w-8 h-0.5 mx-1 transition-colors duration-300 ${i < currentAgent ? 'bg-green-400' : 'bg-gray-200'}`} />
                )}
              </div>
            ))}
          </div>
          {/* Progress text */}
          <div className="text-center mt-2">
            <span className="text-xs text-gray-400">المرحلة {currentAgent + 1} من 6</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Chat Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Agent Info Banner */}
          <div className={`mx-4 mt-4 p-4 rounded-2xl ${currentAgentInfo.bgColor} ${currentAgentInfo.borderColor} border-2 flex items-center gap-4 animate-scaleIn`}>
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl ${currentAgentInfo.bgColor} shadow-sm`}>
              {currentAgentInfo.icon}
            </div>
            <div className="flex-1">
              <p className={`font-bold text-lg ${currentAgentInfo.color}`}>{currentAgentInfo.name}</p>
              <p className="text-sm text-gray-600">{currentAgentInfo.description}</p>
            </div>
            <div className={`hidden sm:flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${currentAgentInfo.bgColor} ${currentAgentInfo.color}`}>
              <span className="w-2 h-2 bg-current rounded-full animate-pulse" />
              نشط
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {study.messages.map((msg) => {
              const agentInfo = agents[msg.agentIndex];
              return (
                <div key={msg.id} className={`chat-bubble flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[85%] sm:max-w-[70%] rounded-2xl p-4 shadow-sm ${
                    msg.role === 'user'
                      ? 'bg-gradient-to-bl from-[#1E3A8A] to-blue-800 text-white rounded-br-md'
                      : `${agentInfo.bgColor} ${agentInfo.color} rounded-bl-md border ${agentInfo.borderColor}`
                  }`}>
                    {msg.role === 'agent' && (
                      <div className="flex items-center gap-1.5 mb-2">
                        <span className="text-base">{agentInfo.icon}</span>
                        <span className="text-xs font-bold opacity-80">{agentInfo.name}</span>
                      </div>
                    )}
                    <p className="whitespace-pre-wrap text-sm leading-relaxed">{msg.content}</p>
                    <p className={`text-[10px] mt-2 ${msg.role === 'user' ? 'text-blue-200' : 'opacity-40'}`}>
                      {new Date(msg.timestamp).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex justify-end chat-bubble">
                <div className={`${currentAgentInfo.bgColor} rounded-2xl rounded-bl-md p-4 border ${currentAgentInfo.borderColor} shadow-sm`}>
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="text-sm">{currentAgentInfo.icon}</span>
                    <span className={`text-xs font-bold ${currentAgentInfo.color} opacity-70`}>{currentAgentInfo.name} يكتب...</span>
                  </div>
                  <div className="typing-indicator flex gap-2 py-1 px-1">
                    <span className={`w-2.5 h-2.5 rounded-full bg-current ${currentAgentInfo.color}`}></span>
                    <span className={`w-2.5 h-2.5 rounded-full bg-current ${currentAgentInfo.color}`}></span>
                    <span className={`w-2.5 h-2.5 rounded-full bg-current ${currentAgentInfo.color}`}></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 bg-white border-t border-gray-200">
            {study.status === 'completed' ? (
              <div className="text-center py-3">
                <button
                  onClick={() => onComplete(study.id)}
                  className="px-8 py-3 bg-gradient-to-l from-green-600 to-green-700 text-white font-bold rounded-2xl hover:shadow-lg hover:shadow-green-500/25 transition-all duration-200 hover:-translate-y-0.5 flex items-center gap-2 mx-auto"
                >
                  <span>📄</span>
                  عرض التقرير النهائي
                </button>
              </div>
            ) : (
              <div className="flex gap-2 max-w-4xl mx-auto">
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      if (currentAgent === 5) handleReportConfirm();
                      else sendMessage();
                    }
                  }}
                  placeholder="اكتب رسالتك هنا..."
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-gray-50 hover:bg-white focus:bg-white"
                  disabled={isTyping}
                  autoFocus
                />
                <button
                  onClick={currentAgent === 5 ? handleReportConfirm : sendMessage}
                  disabled={isTyping || !input.trim()}
                  className="px-6 py-3 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed disabled:shadow-none"
                >
                  إرسال
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className={`${showSidebar ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'} transition-transform duration-300 w-80 border-r border-gray-200 bg-white overflow-y-auto fixed lg:static left-0 top-0 bottom-0 z-30 lg:z-auto shadow-xl lg:shadow-none`}>
          <div className="p-4">
            <div className="flex justify-between items-center mb-4 sticky top-0 bg-white pb-2 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-900">📋 ملخص المعلومات</h3>
              <button onClick={() => setShowSidebar(false)} className="lg:hidden text-gray-500 hover:text-gray-700 w-8 h-8 flex items-center justify-center bg-gray-100 rounded-lg">✕</button>
            </div>

            {/* Progress Overview */}
            <div className="mb-4 p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-gray-500">التقدم العام</span>
                <span className="text-xs font-bold text-[#1E3A8A]">{Math.round((currentAgent / 6) * 100)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-l from-[#1E3A8A] to-blue-500 rounded-full transition-all duration-500" style={{ width: `${(currentAgent / 6) * 100}%` }} />
              </div>
            </div>

            {study.data.project_info && (
              <div className="mb-3 p-3 bg-blue-50 rounded-xl border border-blue-200 animate-fadeIn">
                <h4 className="font-bold text-blue-700 text-sm mb-2 flex items-center gap-1">🕵️ معلومات المشروع</h4>
                <div className="space-y-1.5 text-xs text-gray-700">
                  {study.data.project_info.name && <p className="flex gap-1"><strong className="text-gray-500 min-w-[50px]">الاسم:</strong> <span>{study.data.project_info.name}</span></p>}
                  {study.data.project_info.idea && <p className="flex gap-1"><strong className="text-gray-500 min-w-[50px]">الفكرة:</strong> <span className="line-clamp-2">{study.data.project_info.idea}</span></p>}
                  {study.data.project_info.sector && <p className="flex gap-1"><strong className="text-gray-500 min-w-[50px]">القطاع:</strong> <span>{study.data.project_info.sector}</span></p>}
                  {study.data.project_info.location && <p className="flex gap-1"><strong className="text-gray-500 min-w-[50px]">الموقع:</strong> <span>{study.data.project_info.location}</span></p>}
                  {study.data.project_info.capital && <p className="flex gap-1"><strong className="text-gray-500 min-w-[50px]">رأس المال:</strong> <span>{study.data.project_info.capital}</span></p>}
                </div>
              </div>
            )}

            {study.data.market_analysis && (
              <div className="mb-3 p-3 bg-green-50 rounded-xl border border-green-200 animate-fadeIn">
                <h4 className="font-bold text-green-700 text-sm mb-2 flex items-center gap-1">📊 دراسة السوق</h4>
                <div className="space-y-1.5 text-xs text-gray-700">
                  {study.data.market_analysis.competitors && <p><strong className="text-gray-500">المنافسون:</strong> {study.data.market_analysis.competitors}</p>}
                  {study.data.market_analysis.targetAudience && <p><strong className="text-gray-500">الجمهور:</strong> {study.data.market_analysis.targetAudience}</p>}
                  {study.data.market_analysis.marketSize && <p><strong className="text-gray-500">حجم السوق:</strong> {study.data.market_analysis.marketSize}</p>}
                  {study.data.market_analysis.swot?.strengths?.length > 0 && (
                    <div className="mt-1">
                      <strong className="text-gray-500">SWOT:</strong>
                      <div className="flex flex-wrap gap-1 mt-1">
                        <span className="px-1.5 py-0.5 bg-blue-100 text-blue-700 rounded text-[10px]">💪 {study.data.market_analysis.swot.strengths.length}</span>
                        {study.data.market_analysis.swot.weaknesses?.length > 0 && <span className="px-1.5 py-0.5 bg-red-100 text-red-700 rounded text-[10px]">⚠️ {study.data.market_analysis.swot.weaknesses.length}</span>}
                        {study.data.market_analysis.swot.opportunities?.length > 0 && <span className="px-1.5 py-0.5 bg-green-100 text-green-700 rounded text-[10px]">🌟 {study.data.market_analysis.swot.opportunities.length}</span>}
                        {study.data.market_analysis.swot.threats?.length > 0 && <span className="px-1.5 py-0.5 bg-yellow-100 text-yellow-700 rounded text-[10px]">⛔ {study.data.market_analysis.swot.threats.length}</span>}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {study.data.financial_plan && (
              <div className="mb-3 p-3 bg-yellow-50 rounded-xl border border-yellow-200 animate-fadeIn">
                <h4 className="font-bold text-yellow-700 text-sm mb-2 flex items-center gap-1">💰 الخطة المالية</h4>
                <div className="space-y-1.5 text-xs text-gray-700">
                  <p><strong className="text-gray-500">الإيراد الشهري:</strong> {study.data.financial_plan.revenue?.monthlyRevenue?.toLocaleString() || 0}$</p>
                  <p><strong className="text-gray-500">الإيراد السنوي:</strong> {study.data.financial_plan.revenue?.yearlyRevenue?.toLocaleString() || 0}$</p>
                  <p><strong className="text-gray-500">نقطة التعادل:</strong> {study.data.financial_plan.breakeven?.units || 0} وحدة</p>
                </div>
              </div>
            )}

            {study.data.operational_plan && (
              <div className="mb-3 p-3 bg-purple-50 rounded-xl border border-purple-200 animate-fadeIn">
                <h4 className="font-bold text-purple-700 text-sm mb-2 flex items-center gap-1">⚙️ خطة العمليات</h4>
                <div className="space-y-1.5 text-xs text-gray-700">
                  {study.data.operational_plan.location && <p><strong className="text-gray-500">الموقع:</strong> {study.data.operational_plan.location}</p>}
                  {study.data.operational_plan.equipment && <p><strong className="text-gray-500">المعدات:</strong> {study.data.operational_plan.equipment}</p>}
                  {study.data.operational_plan.orgStructure && <p><strong className="text-gray-500">الموظفون:</strong> {study.data.operational_plan.orgStructure}</p>}
                </div>
              </div>
            )}

            {study.data.marketing_plan && (
              <div className="mb-3 p-3 bg-pink-50 rounded-xl border border-pink-200 animate-fadeIn">
                <h4 className="font-bold text-pink-700 text-sm mb-2 flex items-center gap-1">📢 خطة التسويق</h4>
                <div className="space-y-1.5 text-xs text-gray-700">
                  {study.data.marketing_plan.strategy && <p><strong className="text-gray-500">الاستراتيجية:</strong> {study.data.marketing_plan.strategy}</p>}
                  {study.data.marketing_plan.budget > 0 && <p><strong className="text-gray-500">الميزانية:</strong> {study.data.marketing_plan.budget?.toLocaleString()}$</p>}
                  {study.data.marketing_plan.channels?.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {study.data.marketing_plan.channels.map((ch, i) => (
                        <span key={i} className="px-1.5 py-0.5 bg-pink-100 text-pink-700 rounded text-[10px]">{ch}</span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar overlay for mobile */}
        {showSidebar && (
          <div className="fixed inset-0 bg-black/30 z-20 lg:hidden" onClick={() => setShowSidebar(false)} />
        )}
      </div>
    </div>
  );
}
