interface Props {
  onCheck: () => void;
  onLogout: () => void;
}

export default function WaitingPage({ onCheck, onLogout }: Props) {
  return (
    <div className="min-h-screen bg-gradient-to-bl from-[#1E3A8A] via-blue-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md text-center">
        <div className="bg-white rounded-3xl shadow-2xl p-8 animate-scaleIn">
          {/* Animated waiting icon */}
          <div className="relative w-24 h-24 mx-auto mb-6">
            <div className="absolute inset-0 bg-yellow-100 rounded-full animate-pulse" />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-5xl animate-float">⏳</span>
            </div>
          </div>
          
          <h2 className="text-2xl font-black text-gray-900 mb-3">شكراً لك! 🎉</h2>
          <p className="text-gray-600 mb-1 font-semibold">تم استلام إثبات الدفع الخاص بك بنجاح.</p>
          <p className="text-gray-400 text-sm mb-8">
            جاري مراجعة الإيصال من قبل فريق الإدارة. سيتم تفعيل حسابك في أقرب وقت ممكن.
          </p>

          {/* Steps */}
          <div className="bg-gray-50 rounded-2xl p-4 mb-6 text-right">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center text-sm">✅</div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-green-700">تم إنشاء الحساب</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center text-sm">✅</div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-green-700">تم رفع إثبات الدفع</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center text-sm animate-pulse">⏳</div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-yellow-700">مراجعة الإيصال من الإدارة</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center text-sm">⬜</div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-gray-400">تفعيل الحساب</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 rounded-xl p-4 mb-6 border border-blue-100">
            <p className="text-sm text-blue-700 leading-relaxed">
              💡 <strong>تلميح:</strong> عادة ما تتم المراجعة خلال ساعات قليلة. يمكنك التحقق من حالة حسابك بالضغط على الزر أدناه.
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={onCheck}
              className="w-full py-3.5 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 hover:-translate-y-0.5 flex items-center justify-center gap-2"
            >
              🔄 التحقق من حالة الحساب
            </button>
            <button
              onClick={onLogout}
              className="w-full py-3.5 bg-gray-100 text-gray-600 font-semibold rounded-xl hover:bg-gray-200 transition-all duration-200"
            >
              تسجيل الخروج
            </button>
          </div>
        </div>

        <p className="text-blue-300/50 text-xs mt-6">
          للمسؤول: admin@jadwa.plus / admin123
        </p>
      </div>
    </div>
  );
}
