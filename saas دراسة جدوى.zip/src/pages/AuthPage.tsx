import { useState } from 'react';
import { registerUser, loginUser } from '../store';
import { User } from '../types';

interface Props {
  mode: 'login' | 'register';
  setMode: (m: 'login' | 'register') => void;
  onLogin: (user: User) => void;
  onBack: () => void;
}

export default function AuthPage({ mode, setMode, onLogin, onBack }: Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    setTimeout(() => {
      if (mode === 'register') {
        if (!name || !email || !password || !confirmPassword) {
          setError('يرجى ملء جميع الحقول');
          setLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          setError('كلمات المرور غير متطابقة');
          setLoading(false);
          return;
        }
        if (password.length < 6) {
          setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
          setLoading(false);
          return;
        }
        if (!email.includes('@') || !email.includes('.')) {
          setError('يرجى إدخال بريد إلكتروني صحيح');
          setLoading(false);
          return;
        }
        const result = registerUser(name, email, password);
        if (result.success) {
          setSuccess('تم إنشاء الحساب بنجاح! ✅ يمكنك تسجيل الدخول الآن.');
          setName('');
          setPassword('');
          setConfirmPassword('');
          setTimeout(() => setMode('login'), 2000);
        } else {
          setError(result.message);
        }
      } else {
        if (!email || !password) {
          setError('يرجى إدخال البريد الإلكتروني وكلمة المرور');
          setLoading(false);
          return;
        }
        const result = loginUser(email, password);
        if (result.success && result.user) {
          onLogin(result.user);
        } else {
          setError(result.message);
        }
      }
      setLoading(false);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-bl from-[#1E3A8A] via-blue-800 to-indigo-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <button onClick={onBack} className="text-blue-300 hover:text-white mb-6 inline-flex items-center gap-1.5 transition-colors text-sm font-semibold">
            <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            العودة للرئيسية
          </button>
          <div className="flex items-center justify-center gap-2 mb-3">
            <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-xl shadow-black/10">
              <span className="text-[#1E3A8A] font-black text-3xl">+</span>
            </div>
          </div>
          <h1 className="text-3xl font-black text-white">جدوى+</h1>
          <p className="text-blue-300 text-sm mt-1">منصة دراسات الجدوى بالذكاء الاصطناعي</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 animate-scaleIn">
          <div className="flex mb-6 bg-gray-100 rounded-xl p-1">
            <button
              onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
              className={`flex-1 py-2.5 rounded-lg font-bold text-sm transition-all duration-200 ${mode === 'login' ? 'bg-[#1E3A8A] text-white shadow-lg shadow-blue-500/20' : 'text-gray-500 hover:text-gray-700'}`}
            >
              تسجيل الدخول
            </button>
            <button
              onClick={() => { setMode('register'); setError(''); setSuccess(''); }}
              className={`flex-1 py-2.5 rounded-lg font-bold text-sm transition-all duration-200 ${mode === 'register' ? 'bg-[#1E3A8A] text-white shadow-lg shadow-blue-500/20' : 'text-gray-500 hover:text-gray-700'}`}
            >
              حساب جديد
            </button>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-4 text-sm font-semibold flex items-center gap-2 animate-fadeIn">
              <span>❌</span> {error}
            </div>
          )}
          {success && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl mb-4 text-sm font-semibold flex items-center gap-2 animate-fadeIn">
              <span>✅</span> {success}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div className="animate-fadeIn">
                <label className="block text-sm font-bold text-gray-700 mb-1.5">الاسم الكامل</label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-gray-50 focus:bg-white"
                  placeholder="أدخل اسمك الكامل"
                />
              </div>
            )}
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1.5">البريد الإلكتروني</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-gray-50 focus:bg-white"
                placeholder="email@example.com"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1.5">كلمة المرور</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-gray-50 focus:bg-white pl-12"
                  placeholder="••••••••"
                  dir="ltr"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? '🙈' : '👁️'}
                </button>
              </div>
            </div>
            {mode === 'register' && (
              <div className="animate-fadeIn">
                <label className="block text-sm font-bold text-gray-700 mb-1.5">تأكيد كلمة المرور</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-gray-50 focus:bg-white"
                  placeholder="••••••••"
                  dir="ltr"
                />
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  جاري المعالجة...
                </>
              ) : (
                mode === 'login' ? '🔐 تسجيل الدخول' : '🚀 إنشاء الحساب'
              )}
            </button>
          </form>

          {mode === 'login' && (
            <div className="mt-5 text-center">
              <div className="bg-gradient-to-l from-blue-50 to-indigo-50 p-3 rounded-xl border border-blue-100">
                <p className="text-xs text-blue-700">
                  <strong>🔑 للتجربة كمدير:</strong>
                  <br />
                  <span className="font-mono text-blue-600">admin@jadwa.plus / admin123</span>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
