import { useState, useEffect } from 'react';
import { User, Study } from '../types';
import { getUserStudies, createStudy, deleteStudy, getTodayStudyCount } from '../store';
import { Page } from '../App';

interface Props {
  user: User;
  onLogout: () => void;
  onNavigate: (page: Page) => void;
  onNewStudy: (id: string) => void;
  onViewReport: (id: string) => void;
}

export default function Dashboard({ user, onLogout, onNavigate, onNewStudy, onViewReport }: Props) {
  const [studies, setStudies] = useState<Study[]>([]);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  useEffect(() => {
    setStudies(getUserStudies(user.id));
  }, [user.id]);

  const handleNewStudy = () => {
    if (user.status === 'pending') {
      onNavigate('payment');
      return;
    }
    if (user.status === 'waiting_approval') {
      onNavigate('waiting');
      return;
    }
    if (getTodayStudyCount(user.id) >= 5) {
      alert('لقد وصلت للحد الأقصى من الدراسات اليومية (5 دراسات). حاول مجدداً غداً.');
      return;
    }
    const study = createStudy(user.id, user.name);
    onNewStudy(study.id);
  };

  const handleDelete = (id: string) => {
    deleteStudy(id);
    setStudies(getUserStudies(user.id));
    setShowDeleteConfirm(null);
  };

  const completedStudies = studies.filter(s => s.status === 'completed').length;
  const inProgressStudies = studies.filter(s => s.status === 'in_progress').length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E3A8A] to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                <span className="text-white font-bold text-lg">+</span>
              </div>
              <span className="text-xl font-black text-[#1E3A8A]">جدوى+</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden sm:block text-left">
                <p className="text-sm font-semibold text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">{user.email}</p>
              </div>
              <div className={`w-3 h-3 rounded-full ring-2 ring-offset-1 ${
                user.status === 'approved' ? 'bg-green-500 ring-green-200' :
                user.status === 'waiting_approval' ? 'bg-yellow-500 ring-yellow-200' :
                'bg-gray-400 ring-gray-200'
              }`} />
              <button onClick={onLogout} className="px-4 py-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all duration-200 text-sm font-semibold">
                خروج
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-black text-gray-900">مرحباً، {user.name.split(' ')[0]} 👋</h1>
          <p className="text-gray-500 mt-1">إليك ملخص دراسات الجدوى الخاصة بك</p>
        </div>

        {/* Status Banners */}
        {user.status === 'pending' && (
          <div className="bg-gradient-to-l from-yellow-50 to-orange-50 border border-yellow-200 rounded-2xl p-5 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-fadeIn">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-yellow-100 rounded-2xl flex items-center justify-center text-2xl">💳</div>
              <div>
                <p className="font-bold text-yellow-800">حسابك بانتظار الدفع</p>
                <p className="text-sm text-yellow-700">قم بالدفع لتتمكن من إنشاء دراسات الجدوى</p>
              </div>
            </div>
            <button onClick={() => onNavigate('payment')} className="px-6 py-2.5 bg-gradient-to-l from-yellow-500 to-orange-500 text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-200 whitespace-nowrap">
              ادفع الآن
            </button>
          </div>
        )}

        {user.status === 'waiting_approval' && (
          <div className="bg-gradient-to-l from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-5 mb-6 flex items-center gap-4 animate-fadeIn">
            <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-2xl animate-pulse">⏳</div>
            <div>
              <p className="font-bold text-blue-800">جاري مراجعة إثبات الدفع</p>
              <p className="text-sm text-blue-700">سيتم تفعيل حسابك بعد مراجعة الإيصال من قبل الإدارة</p>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-blue-50 rounded-2xl flex items-center justify-center text-2xl">📊</div>
              <div>
                <p className="text-3xl font-black text-gray-900">{studies.length}</p>
                <p className="text-sm text-gray-500">إجمالي الدراسات</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-gradient-to-br from-green-100 to-green-50 rounded-2xl flex items-center justify-center text-2xl">✅</div>
              <div>
                <p className="text-3xl font-black text-green-600">{completedStudies}</p>
                <p className="text-sm text-gray-500">مكتملة</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-gradient-to-br from-yellow-100 to-yellow-50 rounded-2xl flex items-center justify-center text-2xl">🔄</div>
              <div>
                <p className="text-3xl font-black text-yellow-600">{inProgressStudies}</p>
                <p className="text-sm text-gray-500">قيد الإنشاء</p>
              </div>
            </div>
          </div>
        </div>

        {/* New Study Button */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3">
          <h2 className="text-2xl font-bold text-gray-900">📚 دراساتي</h2>
          <button
            onClick={handleNewStudy}
            className="px-6 py-3 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 hover:-translate-y-0.5 flex items-center gap-2"
          >
            <span className="text-xl leading-none">+</span>
            إنشاء دراسة جديدة
          </button>
        </div>

        {/* Studies List */}
        {studies.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm border border-gray-100">
            <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-4">📋</div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">لا توجد دراسات بعد</h3>
            <p className="text-gray-500 mb-6 max-w-sm mx-auto">ابدأ بإنشاء أول دراسة جدوى لمشروعك واحصل على تقرير احترافي</p>
            <button
              onClick={handleNewStudy}
              className="px-6 py-3 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white font-bold rounded-xl hover:shadow-lg transition-all duration-200"
            >
              🚀 إنشاء دراسة جديدة
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {studies.map((study, idx) => (
              <div key={study.id} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5 animate-fadeInUp" style={{ animationDelay: `${idx * 0.05}s` }}>
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-bold text-gray-900 truncate">{study.projectName}</h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {new Date(study.createdAt).toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                  </div>
                  {study.status === 'completed' ? (
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                      مكتملة
                    </span>
                  ) : (
                    <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-bold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse" />
                      قيد الإنشاء
                    </span>
                  )}
                </div>

                {/* Progress indicator */}
                {study.status === 'in_progress' && (
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] text-gray-400">التقدم</span>
                      <span className="text-[10px] text-gray-400">المرحلة {study.currentAgent + 1}/6</span>
                    </div>
                    <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-l from-blue-500 to-blue-600 rounded-full transition-all" style={{ width: `${((study.currentAgent + 1) / 6) * 100}%` }} />
                    </div>
                  </div>
                )}

                <div className="flex gap-2 mt-4">
                  {study.status === 'completed' ? (
                    <button
                      onClick={() => onViewReport(study.id)}
                      className="flex-1 px-4 py-2.5 bg-gradient-to-l from-green-600 to-green-700 text-white rounded-xl hover:shadow-md transition-all duration-200 font-semibold text-sm flex items-center justify-center gap-1"
                    >
                      📄 عرض التقرير
                    </button>
                  ) : (
                    <button
                      onClick={() => onNewStudy(study.id)}
                      className="flex-1 px-4 py-2.5 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white rounded-xl hover:shadow-md transition-all duration-200 font-semibold text-sm flex items-center justify-center gap-1"
                    >
                      ▶️ متابعة
                    </button>
                  )}
                  {showDeleteConfirm === study.id ? (
                    <div className="flex gap-1">
                      <button onClick={() => handleDelete(study.id)} className="px-3 py-2.5 bg-red-600 text-white rounded-xl text-xs font-bold hover:bg-red-700 transition-colors">تأكيد</button>
                      <button onClick={() => setShowDeleteConfirm(null)} className="px-3 py-2.5 bg-gray-100 text-gray-700 rounded-xl text-xs font-bold hover:bg-gray-200 transition-colors">إلغاء</button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setShowDeleteConfirm(study.id)}
                      className="px-3 py-2.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all duration-200"
                    >
                      🗑️
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
