import { Page } from '../App';

interface Props {
  onNavigate: (page: Page) => void;
  onDemo: () => void;
}

export default function LandingPage({ onNavigate, onDemo }: Props) {
  const features = [
    { icon: '🕵️', title: 'تحليل الأفكار', desc: 'تحليل فكرة مشروعك وتقييمها بشكل شامل ودقيق', color: 'bg-blue-100 text-blue-700', border: 'border-blue-200' },
    { icon: '📊', title: 'دراسة السوق', desc: 'تحليل المنافسين والجمهور المستهدف وحجم السوق', color: 'bg-green-100 text-green-700', border: 'border-green-200' },
    { icon: '💰', title: 'التخطيط المالي', desc: 'بناء نموذج مالي متكامل مع 3 سيناريوهات', color: 'bg-yellow-100 text-yellow-700', border: 'border-yellow-200' },
    { icon: '⚙️', title: 'خطة العمليات', desc: 'تحديد الموارد والمعدات والهيكل التنظيمي', color: 'bg-purple-100 text-purple-700', border: 'border-purple-200' },
    { icon: '📢', title: 'خطة التسويق', desc: 'استراتيجية تسويقية شاملة مع تحديد القنوات', color: 'bg-pink-100 text-pink-700', border: 'border-pink-200' },
    { icon: '📝', title: 'التقرير النهائي', desc: 'تقرير احترافي جاهز للتحميل بصيغة PDF', color: 'bg-red-100 text-red-700', border: 'border-red-200' },
  ];

  const steps = [
    { num: '1', title: 'سجل حسابك', desc: 'أنشئ حسابك مجاناً في ثوانٍ معدودة', icon: '👤' },
    { num: '2', title: 'فعّل حسابك', desc: 'ادفع رسوم الاشتراك البسيطة وارفع الإيصال', icon: '💳' },
    { num: '3', title: 'تحدث مع الوكلاء', desc: 'أجب على أسئلة 6 وكلاء ذكاء اصطناعي متخصصين', icon: '🤖' },
    { num: '4', title: 'حمّل تقريرك', desc: 'احصل على دراسة جدوى احترافية متكاملة', icon: '📥' },
  ];

  const stats = [
    { value: '6', label: 'وكلاء ذكاء اصطناعي' },
    { value: '3', label: 'سيناريوهات مالية' },
    { value: '10', label: 'دقائق فقط' },
    { value: 'PDF', label: 'تقرير احترافي' },
  ];

  return (
    <div className="min-h-screen">
      {/* Navbar */}
      <nav className="bg-white/90 backdrop-blur-md shadow-sm sticky top-0 z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E3A8A] to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                <span className="text-white font-bold text-lg">+</span>
              </div>
              <span className="text-2xl font-black text-[#1E3A8A]">جدوى+</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate('auth')}
                className="px-5 py-2 text-[#1E3A8A] font-semibold hover:bg-blue-50 rounded-lg transition-all duration-200"
              >
                تسجيل الدخول
              </button>
              <button
                onClick={() => onNavigate('auth')}
                className="px-5 py-2 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white font-semibold rounded-lg hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 hover:-translate-y-0.5"
              >
                إنشاء حساب
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative bg-gradient-to-bl from-[#1E3A8A] via-blue-800 to-indigo-900 text-white py-20 lg:py-32 overflow-hidden">
        {/* Background decorations */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -left-40 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-600/5 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="animate-fadeIn">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 rounded-full text-sm mb-8 backdrop-blur-sm border border-white/10">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              مدعوم بأحدث نماذج الذكاء الاصطناعي من NVIDIA
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-black mb-6 leading-tight tracking-tight">
              أنشئ دراسة جدوى
              <br />
              <span className="bg-gradient-to-l from-blue-300 to-cyan-300 bg-clip-text text-transparent">احترافية</span>
              {' '}في دقائق
            </h1>
            <p className="text-lg sm:text-xl text-blue-200/90 max-w-2xl mx-auto mb-12 leading-relaxed">
              6 وكلاء ذكاء اصطناعي متخصصين يعملون معاً لبناء دراسة جدوى شاملة لمشروعك.
              من تحليل الفكرة إلى التقرير النهائي الجاهز للتحميل.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('auth')}
                className="px-8 py-4 bg-white text-[#1E3A8A] font-bold rounded-2xl text-lg hover:bg-blue-50 transition-all duration-300 shadow-xl shadow-black/10 hover:shadow-2xl hover:-translate-y-1 active:translate-y-0"
              >
                🚀 ابدأ الآن مجاناً
              </button>
              <button
                onClick={onDemo}
                className="px-8 py-4 bg-white/10 text-white font-bold rounded-2xl text-lg hover:bg-white/20 transition-all duration-300 border border-white/20 backdrop-blur-sm hover:-translate-y-1 active:translate-y-0"
              >
                👁️ جرّب العرض التجريبي
              </button>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-20 grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-8 max-w-3xl mx-auto">
            {stats.map((stat, i) => (
              <div key={i} className="text-center animate-fadeInUp" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="text-3xl sm:text-4xl font-black text-white mb-1">{stat.value}</div>
                <div className="text-sm text-blue-300">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-4">الوكلاء الأذكياء</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 mb-4">6 وكلاء ذكاء اصطناعي في خدمتك</h2>
            <p className="text-gray-500 text-lg max-w-2xl mx-auto">كل وكيل متخصص في جانب مختلف من دراسة الجدوى لضمان أفضل النتائج</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <div key={i} className={`bg-white border ${f.border} rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group`} style={{ animationDelay: `${i * 0.1}s` }}>
                <div className={`w-16 h-16 ${f.color} rounded-2xl flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  {f.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{f.title}</h3>
                <p className="text-gray-500 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 lg:py-28 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold mb-4">سهل وسريع</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 mb-4">كيف يعمل؟</h2>
            <p className="text-gray-500 text-lg">4 خطوات بسيطة للحصول على دراسة جدوى احترافية</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((s, i) => (
              <div key={i} className="text-center relative">
                <div className="w-20 h-20 bg-gradient-to-br from-[#1E3A8A] to-blue-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/20">
                  <span className="text-3xl">{s.icon}</span>
                </div>
                <div className="absolute top-10 left-0 -translate-x-1/2 w-8 h-8 bg-white border-2 border-[#1E3A8A] rounded-full flex items-center justify-center text-sm font-bold text-[#1E3A8A] shadow-md">
                  {s.num}
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-gray-500 text-sm">{s.desc}</p>
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-0 -translate-x-full w-full h-0.5 bg-gradient-to-l from-blue-300 to-transparent" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-lg mx-auto px-4">
          <div className="text-center mb-10">
            <span className="inline-block px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-semibold mb-4">تسعير شفاف</span>
            <h2 className="text-3xl sm:text-4xl font-black text-gray-900 mb-4">سعر بسيط، قيمة كبيرة</h2>
          </div>
          <div className="bg-gradient-to-br from-[#1E3A8A] via-blue-800 to-indigo-800 rounded-3xl p-8 text-white text-center shadow-2xl shadow-blue-900/30 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImEiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCI+PHBhdGggZD0iTTAgMGg2MHY2MEgweiIgZmlsbD0ibm9uZSIvPjxwYXRoIGQ9Ik0zMCAwdjYwTTAgMzBoNjAiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2EpIi8+PC9zdmc+')] opacity-50" />
            <div className="relative z-10">
              <span className="inline-block px-4 py-1 bg-white/20 rounded-full text-sm mb-6 backdrop-blur-sm">⭐ الأكثر شعبية</span>
              <div className="text-6xl font-black mb-2">29$</div>
              <p className="text-blue-200 mb-8 text-lg">لكل دراسة جدوى</p>
              <ul className="space-y-3 text-right mb-8">
                {['6 وكلاء ذكاء اصطناعي متخصصين', 'تقرير PDF احترافي متكامل', 'نماذج مالية تفاعلية مع 3 سيناريوهات', 'تحليل SWOT شامل', 'رسوم بيانية توضيحية', 'دعم كامل للغة العربية'].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-green-400/20 rounded-full flex items-center justify-center text-xs text-green-400">✓</span>
                    <span className="text-blue-100">{item}</span>
                  </li>
                ))}
              </ul>
              <button
                onClick={() => onNavigate('auth')}
                className="w-full py-4 bg-white text-[#1E3A8A] font-bold rounded-2xl hover:bg-blue-50 transition-all duration-200 text-lg shadow-lg"
              >
                ابدأ الآن
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl sm:text-4xl font-black text-gray-900 mb-4">جاهز لبدء مشروعك؟</h2>
          <p className="text-gray-500 text-lg mb-8">لا تضيع وقتك في البحث والتحليل، دع الذكاء الاصطناعي يقوم بالعمل</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('auth')}
              className="px-8 py-4 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white font-bold rounded-2xl text-lg hover:shadow-xl hover:shadow-blue-500/25 transition-all duration-300 hover:-translate-y-1"
            >
              🚀 ابدأ الآن
            </button>
            <button
              onClick={onDemo}
              className="px-8 py-4 bg-white text-[#1E3A8A] font-bold rounded-2xl text-lg hover:bg-gray-100 transition-all duration-300 border border-gray-200 hover:-translate-y-1"
            >
              جرّب مجاناً
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-[#1E3A8A] to-blue-600 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-lg">+</span>
                </div>
                <span className="text-xl font-bold text-white">جدوى+</span>
              </div>
              <p className="text-sm leading-relaxed">منصة متكاملة لإنشاء دراسات الجدوى الاحترافية باستخدام أحدث تقنيات الذكاء الاصطناعي.</p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">المنصة</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => onNavigate('auth')} className="hover:text-white transition-colors">إنشاء حساب</button></li>
                <li><button onClick={() => onNavigate('auth')} className="hover:text-white transition-colors">تسجيل الدخول</button></li>
                <li><button onClick={onDemo} className="hover:text-white transition-colors">العرض التجريبي</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">الوكلاء</h4>
              <ul className="space-y-2 text-sm">
                <li>🕵️ محلل الأفكار</li>
                <li>📊 باحث السوق</li>
                <li>💰 المخطط المالي</li>
                <li>⚙️ مخطط العمليات</li>
                <li>📢 خبير التسويق</li>
                <li>📝 كاتب التقرير</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-sm">© {new Date().getFullYear()} جدوى+. جميع الحقوق محفوظة. مدعوم بتقنيات NVIDIA AI.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
