import { useState, useEffect } from 'react';
import { Study } from '../types';
import { getStudyById } from '../store';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface Props {
  studyId: string;
  onBack: () => void;
}

export default function ReportPage({ studyId, onBack }: Props) {
  const [study, setStudy] = useState<Study | null>(null);
  const [activeTab, setActiveTab] = useState<'report' | 'financial' | 'charts'>('report');

  useEffect(() => {
    const s = getStudyById(studyId);
    if (s) setStudy(s);
  }, [studyId]);

  const handleExportPDF = () => {
    window.print();
  };

  if (!study) return <div className="min-h-screen flex items-center justify-center text-gray-500">جاري التحميل...</div>;

  const fp = study.data.financial_plan;
  const ma = study.data.market_analysis;
  const pi = study.data.project_info;
  const op = study.data.operational_plan;
  const mp = study.data.marketing_plan;

  const totalFixed = fp?.fixedCosts?.reduce((s, c) => s + c.amount, 0) || 0;
  const totalVariable = fp?.variableCosts?.reduce((s, c) => s + c.amount, 0) || 0;

  const scenarioData = fp?.scenarios ? [
    { name: 'متشائم', revenue: fp.scenarios.pessimistic.revenue, profit: fp.scenarios.pessimistic.profit },
    { name: 'واقعي', revenue: fp.scenarios.realistic.revenue, profit: fp.scenarios.realistic.profit },
    { name: 'متفائل', revenue: fp.scenarios.optimistic.revenue, profit: fp.scenarios.optimistic.profit },
  ] : [];

  const costData = [
    { name: 'تكاليف ثابتة', value: totalFixed, color: '#3B82F6' },
    { name: 'تكاليف متغيرة (سنوي)', value: totalVariable * 12, color: '#F59E0B' },
  ];

  const tabs = [
    { id: 'report' as const, label: '📄 التقرير', },
    { id: 'financial' as const, label: '💰 الجداول المالية', },
    { id: 'charts' as const, label: '📊 الرسوم البيانية', },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm print:hidden">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center gap-3">
              <button onClick={onBack} className="px-3 py-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors text-sm font-semibold">
                → رجوع
              </button>
              <span className="text-lg font-bold text-gray-900">تقرير: {study.projectName}</span>
            </div>
            <button onClick={handleExportPDF} className="px-5 py-2 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 transition-colors flex items-center gap-2">
              📥 تحميل PDF
            </button>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200 print:hidden">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-5 py-3 font-semibold text-sm border-b-2 transition-all ${
                  activeTab === tab.id
                    ? 'border-[#1E3A8A] text-[#1E3A8A]'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <main className="max-w-5xl mx-auto px-4 py-8">
        {/* Report Tab */}
        {activeTab === 'report' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden print:shadow-none print:border-none">
            {/* Title Page */}
            <div className="bg-gradient-to-bl from-[#1E3A8A] to-blue-800 text-white p-12 text-center">
              <p className="text-blue-300 text-sm mb-2">دراسة جدوى</p>
              <h1 className="text-4xl font-black mb-4">{pi?.name || study.projectName}</h1>
              <p className="text-blue-200 mb-6">{pi?.idea}</p>
              <div className="flex items-center justify-center gap-6 text-sm text-blue-300">
                <span>📅 {new Date(study.createdAt).toLocaleDateString('ar-SA')}</span>
                <span>📍 {pi?.location}</span>
                <span>🏭 {pi?.sector}</span>
              </div>
              <div className="mt-6 flex items-center justify-center gap-2">
                <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">+</span>
                </div>
                <span className="text-sm">إعداد منصة جدوى+</span>
              </div>
            </div>

            {/* Content */}
            <div className="p-8 space-y-8">
              {/* Executive Summary */}
              <section>
                <h2 className="text-2xl font-bold text-[#1E3A8A] border-b-2 border-blue-200 pb-2 mb-4">الملخص التنفيذي</h2>
                <p className="text-gray-700 leading-relaxed">
                  تقدم هذه الدراسة تحليلاً شاملاً لمشروع "{pi?.name}" في قطاع {pi?.sector} بمنطقة {pi?.location}. 
                  المشروع يهدف إلى {pi?.idea}. برأس مال مبدئي قدره {pi?.capital}.
                </p>
              </section>

              {/* Project Info */}
              <section>
                <h2 className="text-2xl font-bold text-[#1E3A8A] border-b-2 border-blue-200 pb-2 mb-4">وصف المشروع</h2>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: 'اسم المشروع', value: pi?.name },
                    { label: 'القطاع', value: pi?.sector },
                    { label: 'الموقع', value: pi?.location },
                    { label: 'رأس المال', value: pi?.capital },
                  ].map((item, i) => (
                    <div key={i} className="bg-gray-50 p-3 rounded-xl">
                      <p className="text-xs text-gray-500 mb-1">{item.label}</p>
                      <p className="font-semibold text-gray-900">{item.value || '-'}</p>
                    </div>
                  ))}
                </div>
                <div className="bg-gray-50 p-3 rounded-xl mt-4">
                  <p className="text-xs text-gray-500 mb-1">فكرة المشروع</p>
                  <p className="font-semibold text-gray-900">{pi?.idea || '-'}</p>
                </div>
              </section>

              {/* Market Study */}
              {ma && (
                <section>
                  <h2 className="text-2xl font-bold text-[#1E3A8A] border-b-2 border-blue-200 pb-2 mb-4">دراسة السوق</h2>
                  <div className="space-y-4">
                    <div className="bg-green-50 p-4 rounded-xl">
                      <h3 className="font-bold text-green-700 mb-2">المنافسون</h3>
                      <p className="text-gray-700">{ma.competitors}</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-xl">
                      <h3 className="font-bold text-green-700 mb-2">الجمهور المستهدف</h3>
                      <p className="text-gray-700">{ma.targetAudience}</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-xl">
                      <h3 className="font-bold text-green-700 mb-2">حجم السوق</h3>
                      <p className="text-gray-700">{ma.marketSize}</p>
                    </div>

                    {/* SWOT */}
                    <h3 className="font-bold text-gray-900 text-lg mt-6">تحليل SWOT</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                        <h4 className="font-bold text-blue-700 mb-2">💪 نقاط القوة</h4>
                        <ul className="space-y-1">
                          {ma.swot?.strengths?.map((s, i) => <li key={i} className="text-sm text-gray-700">• {s}</li>)}
                        </ul>
                      </div>
                      <div className="bg-red-50 p-4 rounded-xl border border-red-200">
                        <h4 className="font-bold text-red-700 mb-2">⚠️ نقاط الضعف</h4>
                        <ul className="space-y-1">
                          {ma.swot?.weaknesses?.map((w, i) => <li key={i} className="text-sm text-gray-700">• {w}</li>)}
                        </ul>
                      </div>
                      <div className="bg-green-50 p-4 rounded-xl border border-green-200">
                        <h4 className="font-bold text-green-700 mb-2">🌟 الفرص</h4>
                        <ul className="space-y-1">
                          {ma.swot?.opportunities?.map((o, i) => <li key={i} className="text-sm text-gray-700">• {o}</li>)}
                        </ul>
                      </div>
                      <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
                        <h4 className="font-bold text-yellow-700 mb-2">⛔ التهديدات</h4>
                        <ul className="space-y-1">
                          {ma.swot?.threats?.map((t, i) => <li key={i} className="text-sm text-gray-700">• {t}</li>)}
                        </ul>
                      </div>
                    </div>
                  </div>
                </section>
              )}

              {/* Operational Plan */}
              {op && (
                <section>
                  <h2 className="text-2xl font-bold text-[#1E3A8A] border-b-2 border-blue-200 pb-2 mb-4">الخطة التشغيلية</h2>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: 'نوع الموقع', value: op.location, icon: '📍' },
                      { label: 'المعدات', value: op.equipment, icon: '🔧' },
                      { label: 'الهيكل التنظيمي', value: op.orgStructure, icon: '👥' },
                      { label: 'التراخيص', value: op.licenses, icon: '📋' },
                    ].map((item, i) => (
                      <div key={i} className="bg-purple-50 p-4 rounded-xl">
                        <p className="text-sm text-purple-600 mb-1">{item.icon} {item.label}</p>
                        <p className="text-gray-900 font-semibold">{item.value || '-'}</p>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Marketing Plan */}
              {mp && (
                <section>
                  <h2 className="text-2xl font-bold text-[#1E3A8A] border-b-2 border-blue-200 pb-2 mb-4">الخطة التسويقية</h2>
                  <div className="space-y-4">
                    <div className="bg-pink-50 p-4 rounded-xl">
                      <h3 className="font-bold text-pink-700 mb-2">الاستراتيجية</h3>
                      <p className="text-gray-700">{mp.strategy}</p>
                    </div>
                    <div className="bg-pink-50 p-4 rounded-xl">
                      <h3 className="font-bold text-pink-700 mb-2">قنوات التسويق</h3>
                      <div className="flex flex-wrap gap-2">
                        {mp.channels?.map((ch, i) => (
                          <span key={i} className="px-3 py-1 bg-pink-200 text-pink-800 rounded-full text-sm font-semibold">{ch}</span>
                        ))}
                      </div>
                    </div>
                    <div className="bg-pink-50 p-4 rounded-xl">
                      <h3 className="font-bold text-pink-700 mb-2">الميزانية الشهرية</h3>
                      <p className="text-2xl font-bold text-pink-800">{mp.budget?.toLocaleString() || 0} $</p>
                    </div>
                  </div>
                </section>
              )}

              {/* Recommendations */}
              <section>
                <h2 className="text-2xl font-bold text-[#1E3A8A] border-b-2 border-blue-200 pb-2 mb-4">التوصيات</h2>
                <div className="space-y-2">
                  {[
                    'البدء بنطاق محدود واختبار السوق قبل التوسع',
                    'بناء علاقات قوية مع العملاء الأوائل',
                    'مراقبة التدفقات النقدية بشكل دوري',
                    'تطوير ميزة تنافسية واضحة',
                    'الاستثمار في التسويق الرقمي بشكل مدروس',
                  ].map((rec, i) => (
                    <div key={i} className="flex items-start gap-2 bg-blue-50 p-3 rounded-xl">
                      <span className="text-blue-600 font-bold">{i + 1}.</span>
                      <p className="text-gray-700">{rec}</p>
                    </div>
                  ))}
                </div>
              </section>

              {/* Footer */}
              <div className="text-center text-sm text-gray-500 border-t border-gray-200 pt-6">
                <p>تم إعداد هذا التقرير بواسطة منصة جدوى+ باستخدام الذكاء الاصطناعي</p>
                <p>هذا التقرير استرشادي ولا يغني عن استشارة الخبراء المتخصصين</p>
              </div>
            </div>
          </div>
        )}

        {/* Financial Tables Tab */}
        {activeTab === 'financial' && fp && (
          <div className="space-y-6">
            {/* Fixed Costs */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="bg-blue-50 px-6 py-4 border-b border-blue-200">
                <h3 className="text-lg font-bold text-blue-800">📊 التكاليف التأسيسية (الثابتة)</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">#</th>
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">البند</th>
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">المبلغ ($)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fp.fixedCosts?.map((cost, i) => (
                      <tr key={i} className="border-t border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-3 text-sm text-gray-500">{i + 1}</td>
                        <td className="px-6 py-3 text-sm font-semibold text-gray-900">{cost.item}</td>
                        <td className="px-6 py-3 text-sm font-bold text-gray-900">{cost.amount.toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 border-blue-300 bg-blue-50">
                      <td colSpan={2} className="px-6 py-3 text-sm font-bold text-blue-800">الإجمالي</td>
                      <td className="px-6 py-3 text-sm font-black text-blue-800">{totalFixed.toLocaleString()} $</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Variable Costs */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="bg-yellow-50 px-6 py-4 border-b border-yellow-200">
                <h3 className="text-lg font-bold text-yellow-800">📊 التكاليف التشغيلية الشهرية (المتغيرة)</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">#</th>
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">البند</th>
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">المبلغ الشهري ($)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fp.variableCosts?.map((cost, i) => (
                      <tr key={i} className="border-t border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-3 text-sm text-gray-500">{i + 1}</td>
                        <td className="px-6 py-3 text-sm font-semibold text-gray-900">{cost.item}</td>
                        <td className="px-6 py-3 text-sm font-bold text-gray-900">{cost.amount.toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 border-yellow-300 bg-yellow-50">
                      <td colSpan={2} className="px-6 py-3 text-sm font-bold text-yellow-800">الإجمالي الشهري</td>
                      <td className="px-6 py-3 text-sm font-black text-yellow-800">{totalVariable.toLocaleString()} $</td>
                    </tr>
                    <tr className="bg-yellow-50">
                      <td colSpan={2} className="px-6 py-3 text-sm font-bold text-yellow-800">الإجمالي السنوي</td>
                      <td className="px-6 py-3 text-sm font-black text-yellow-800">{(totalVariable * 12).toLocaleString()} $</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Revenue */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="bg-green-50 px-6 py-4 border-b border-green-200">
                <h3 className="text-lg font-bold text-green-800">💰 الإيرادات المتوقعة</h3>
              </div>
              <div className="p-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { label: 'العملاء/شهر', value: fp.revenue?.monthlyClients || 0, suffix: '' },
                  { label: 'متوسط السعر', value: fp.revenue?.avgPrice || 0, suffix: '$' },
                  { label: 'الإيراد الشهري', value: fp.revenue?.monthlyRevenue || 0, suffix: '$' },
                  { label: 'الإيراد السنوي', value: fp.revenue?.yearlyRevenue || 0, suffix: '$' },
                ].map((item, i) => (
                  <div key={i} className="bg-green-50 p-4 rounded-xl text-center">
                    <p className="text-xs text-green-600 mb-1">{item.label}</p>
                    <p className="text-2xl font-black text-green-800">{item.value.toLocaleString()}{item.suffix}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Breakeven */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="bg-purple-50 px-6 py-4 border-b border-purple-200">
                <h3 className="text-lg font-bold text-purple-800">📈 نقطة التعادل</h3>
              </div>
              <div className="p-6 grid grid-cols-2 gap-4">
                <div className="bg-purple-50 p-6 rounded-xl text-center">
                  <p className="text-sm text-purple-600 mb-2">بالوحدات</p>
                  <p className="text-3xl font-black text-purple-800">{fp.breakeven?.units || 0}</p>
                  <p className="text-xs text-purple-500">وحدة</p>
                </div>
                <div className="bg-purple-50 p-6 rounded-xl text-center">
                  <p className="text-sm text-purple-600 mb-2">بالقيمة</p>
                  <p className="text-3xl font-black text-purple-800">{fp.breakeven?.value?.toLocaleString() || 0}</p>
                  <p className="text-xs text-purple-500">$</p>
                </div>
              </div>
            </div>

            {/* Scenarios */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="bg-orange-50 px-6 py-4 border-b border-orange-200">
                <h3 className="text-lg font-bold text-orange-800">🔄 السيناريوهات المالية</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">السيناريو</th>
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">الإيراد السنوي ($)</th>
                      <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">الربح السنوي ($)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-t border-gray-100 bg-green-50">
                      <td className="px-6 py-3 text-sm font-bold text-green-700">🟢 متفائل</td>
                      <td className="px-6 py-3 text-sm font-bold text-green-700">{fp.scenarios?.optimistic?.revenue?.toLocaleString()}</td>
                      <td className="px-6 py-3 text-sm font-bold text-green-700">{fp.scenarios?.optimistic?.profit?.toLocaleString()}</td>
                    </tr>
                    <tr className="border-t border-gray-100 bg-blue-50">
                      <td className="px-6 py-3 text-sm font-bold text-blue-700">🔵 واقعي</td>
                      <td className="px-6 py-3 text-sm font-bold text-blue-700">{fp.scenarios?.realistic?.revenue?.toLocaleString()}</td>
                      <td className="px-6 py-3 text-sm font-bold text-blue-700">{fp.scenarios?.realistic?.profit?.toLocaleString()}</td>
                    </tr>
                    <tr className="border-t border-gray-100 bg-red-50">
                      <td className="px-6 py-3 text-sm font-bold text-red-700">🔴 متشائم</td>
                      <td className="px-6 py-3 text-sm font-bold text-red-700">{fp.scenarios?.pessimistic?.revenue?.toLocaleString()}</td>
                      <td className="px-6 py-3 text-sm font-bold text-red-700">{fp.scenarios?.pessimistic?.profit?.toLocaleString()}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Charts Tab */}
        {activeTab === 'charts' && fp && (
          <div className="space-y-6">
            {/* Scenarios Chart */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">📊 مقارنة السيناريوهات المالية</h3>
              <div style={{ direction: 'ltr' }}>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={scenarioData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => String(value).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' $'} />
                    <Bar dataKey="revenue" name="الإيراد" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="profit" name="الربح" fill="#10B981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Cost Distribution */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">🥧 توزيع التكاليف</h3>
              <div style={{ direction: 'ltr' }}>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={costData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      dataKey="value"
                      label={((props: any) => `${props.name || ''}: ${Number(props.value || 0).toLocaleString()}$`) as any}
                    >
                      {costData.map((entry, index) => (
                        <Cell key={index} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => String(value).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' $'} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Monthly Revenue vs Cost */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">📈 الإيراد الشهري مقابل التكاليف</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-green-50 p-6 rounded-xl text-center">
                  <p className="text-sm text-green-600 mb-2">الإيراد الشهري</p>
                  <p className="text-3xl font-black text-green-700">{(fp.revenue?.monthlyRevenue || 0).toLocaleString()}</p>
                  <p className="text-xs text-green-500">$</p>
                </div>
                <div className="bg-red-50 p-6 rounded-xl text-center">
                  <p className="text-sm text-red-600 mb-2">التكاليف الشهرية</p>
                  <p className="text-3xl font-black text-red-700">{totalVariable.toLocaleString()}</p>
                  <p className="text-xs text-red-500">$</p>
                </div>
                <div className={`p-6 rounded-xl text-center ${(fp.revenue?.monthlyRevenue || 0) > totalVariable ? 'bg-green-50' : 'bg-red-50'}`}>
                  <p className="text-sm text-gray-600 mb-2">صافي الربح الشهري</p>
                  <p className={`text-3xl font-black ${(fp.revenue?.monthlyRevenue || 0) > totalVariable ? 'text-green-700' : 'text-red-700'}`}>
                    {((fp.revenue?.monthlyRevenue || 0) - totalVariable).toLocaleString()}
                  </p>
                  <p className="text-xs text-gray-500">$</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
