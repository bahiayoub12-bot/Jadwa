import { useState, useEffect } from 'react';
import { User, Study } from '../types';
import { getUsers, getStudies, updateUserStatus, deleteUser, deleteStudy, getPaymentSettings, updatePaymentSettings } from '../store';
import { PaymentSettings, AccountStatus } from '../types';

interface Props {
  user: User;
  onLogout: () => void;
}

export default function AdminPanel({ user, onLogout }: Props) {
  const [activeTab, setActiveTab] = useState<'users' | 'studies' | 'settings'>('users');
  const [users, setUsers] = useState<User[]>([]);
  const [studies, setStudies] = useState<Study[]>([]);
  const [settings, setSettings] = useState<PaymentSettings>(getPaymentSettings());
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [showReceipt, setShowReceipt] = useState<string | null>(null);
  const [showStudyReport, setShowStudyReport] = useState<string | null>(null);
  const [settingsSaved, setSettingsSaved] = useState(false);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setUsers(getUsers());
    setStudies(getStudies());
  };

  const handleStatusChange = (userId: string, status: AccountStatus) => {
    updateUserStatus(userId, status);
    refreshData();
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
      deleteUser(userId);
      refreshData();
    }
  };

  const handleDeleteStudy = (studyId: string) => {
    if (confirm('هل أنت متأكد من حذف هذه الدراسة؟')) {
      deleteStudy(studyId);
      refreshData();
    }
  };

  const handleSaveSettings = () => {
    updatePaymentSettings(settings);
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 3000);
  };

  const filteredUsers = users.filter(u => {
    if (u.role === 'admin') return false;
    if (filterStatus !== 'all' && u.status !== filterStatus) return false;
    if (search && !u.name.includes(search) && !u.email.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const waitingCount = users.filter(u => u.status === 'waiting_approval').length;
  const approvedCount = users.filter(u => u.status === 'approved' && u.role !== 'admin').length;
  const totalUsers = users.filter(u => u.role !== 'admin').length;

  const getStatusBadge = (status: string) => {
    const config: Record<string, { bg: string; text: string; label: string; dot: string }> = {
      pending: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'بانتظار الدفع', dot: 'bg-gray-400' },
      waiting_approval: { bg: 'bg-yellow-100', text: 'text-yellow-700', label: 'بانتظار المراجعة', dot: 'bg-yellow-500' },
      approved: { bg: 'bg-green-100', text: 'text-green-700', label: 'مفعّل', dot: 'bg-green-500' },
    };
    const c = config[status] || config.pending;
    return (
      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${c.bg} ${c.text}`}>
        <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />
        {c.label}
      </span>
    );
  };

  const tabs = [
    { id: 'users' as const, label: '👥 المستخدمون', count: totalUsers },
    { id: 'studies' as const, label: '📊 الدراسات', count: studies.length },
    { id: 'settings' as const, label: '⚙️ الإعدادات', count: 0 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-l from-[#1E3A8A] to-indigo-800 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <span className="font-bold text-lg">+</span>
              </div>
              <div>
                <span className="text-xl font-bold">جدوى+</span>
                <span className="text-blue-300 text-sm mr-2 hidden sm:inline">| لوحة الإدارة</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center text-sm">👤</div>
                <span className="text-sm text-blue-200">{user.name}</span>
              </div>
              <button onClick={onLogout} className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all duration-200 text-sm font-semibold border border-white/10">
                خروج
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-5 py-3.5 font-semibold text-sm border-b-2 transition-all duration-200 flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'border-[#1E3A8A] text-[#1E3A8A]'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
                {tab.count > 0 && (
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                    activeTab === tab.id ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'
                  }`}>{tab.count}</span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'إجمالي المستخدمين', value: totalUsers, icon: '👥', color: 'text-gray-900', bg: 'bg-gray-50' },
            { label: 'بانتظار المراجعة', value: waitingCount, icon: '⏳', color: 'text-yellow-600', bg: 'bg-yellow-50' },
            { label: 'حسابات مفعّلة', value: approvedCount, icon: '✅', color: 'text-green-600', bg: 'bg-green-50' },
            { label: 'إجمالي الدراسات', value: studies.length, icon: '📊', color: 'text-blue-600', bg: 'bg-blue-50' },
          ].map((stat, i) => (
            <div key={i} className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 ${stat.bg} rounded-xl flex items-center justify-center text-xl`}>{stat.icon}</div>
                <div>
                  <p className={`text-2xl font-black ${stat.color}`}>{stat.value}</p>
                  <p className="text-xs text-gray-500">{stat.label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-200 flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="بحث بالاسم أو البريد..."
                  className="w-full pr-10 pl-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-gray-50 focus:bg-white transition-colors"
                />
              </div>
              <select
                value={filterStatus}
                onChange={e => setFilterStatus(e.target.value)}
                className="px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-gray-50 focus:bg-white cursor-pointer"
              >
                <option value="all">جميع الحالات</option>
                <option value="pending">بانتظار الدفع</option>
                <option value="waiting_approval">بانتظار المراجعة</option>
                <option value="approved">مفعّل</option>
              </select>
              <button onClick={refreshData} className="px-4 py-2.5 bg-gray-100 hover:bg-gray-200 rounded-xl text-sm font-semibold transition-colors">
                🔄 تحديث
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">الاسم</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">البريد الإلكتروني</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider hidden sm:table-cell">تاريخ التسجيل</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">الحالة</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">الإيصال</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredUsers.map(u => (
                    <tr key={u.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-sm font-bold text-blue-700">
                            {u.name.charAt(0)}
                          </div>
                          <span className="text-sm font-semibold text-gray-900">{u.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600" dir="ltr">{u.email}</td>
                      <td className="px-4 py-3 text-sm text-gray-500 hidden sm:table-cell">{new Date(u.createdAt).toLocaleDateString('ar-SA')}</td>
                      <td className="px-4 py-3">{getStatusBadge(u.status)}</td>
                      <td className="px-4 py-3">
                        {u.receiptUrl ? (
                          <button
                            onClick={() => setShowReceipt(u.receiptUrl || null)}
                            className="px-3 py-1.5 bg-blue-100 text-blue-700 rounded-lg text-xs font-bold hover:bg-blue-200 transition-colors"
                          >
                            👁️ عرض
                          </button>
                        ) : (
                          <span className="text-xs text-gray-400 italic">لا يوجد</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1.5">
                          {u.status !== 'approved' && (
                            <button
                              onClick={() => handleStatusChange(u.id, 'approved')}
                              className="px-2.5 py-1.5 bg-green-100 text-green-700 rounded-lg text-xs font-bold hover:bg-green-200 transition-colors"
                              title="تفعيل الحساب"
                            >
                              ✅ تفعيل
                            </button>
                          )}
                          {u.status === 'waiting_approval' && (
                            <button
                              onClick={() => handleStatusChange(u.id, 'pending')}
                              className="px-2.5 py-1.5 bg-red-100 text-red-700 rounded-lg text-xs font-bold hover:bg-red-200 transition-colors"
                              title="رفض الطلب"
                            >
                              ❌ رفض
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteUser(u.id)}
                            className="px-2.5 py-1.5 bg-gray-100 text-gray-600 rounded-lg text-xs font-bold hover:bg-red-100 hover:text-red-700 transition-colors"
                            title="حذف المستخدم"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredUsers.length === 0 && (
                <div className="text-center py-16 text-gray-500">
                  <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-3">👥</div>
                  <p className="font-semibold">لا يوجد مستخدمون</p>
                  <p className="text-sm text-gray-400 mt-1">لم يتم العثور على مستخدمين بهذه المعايير</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Studies Tab */}
        {activeTab === 'studies' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">المستخدم</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">اسم المشروع</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider hidden sm:table-cell">تاريخ الإنشاء</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">الحالة</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {studies.map(s => (
                    <tr key={s.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center text-sm font-bold text-purple-700">
                            {s.userName.charAt(0)}
                          </div>
                          <span className="text-sm font-semibold text-gray-900">{s.userName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-700 font-medium">{s.projectName}</td>
                      <td className="px-4 py-3 text-sm text-gray-500 hidden sm:table-cell">{new Date(s.createdAt).toLocaleDateString('ar-SA')}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                          s.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${s.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500 animate-pulse'}`} />
                          {s.status === 'completed' ? 'مكتملة' : 'قيد الإنشاء'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1.5">
                          {s.report && (
                            <button
                              onClick={() => setShowStudyReport(s.report || null)}
                              className="px-2.5 py-1.5 bg-blue-100 text-blue-700 rounded-lg text-xs font-bold hover:bg-blue-200 transition-colors"
                            >
                              📄 عرض
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteStudy(s.id)}
                            className="px-2.5 py-1.5 bg-gray-100 text-gray-600 rounded-lg text-xs font-bold hover:bg-red-100 hover:text-red-700 transition-colors"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {studies.length === 0 && (
                <div className="text-center py-16 text-gray-500">
                  <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-3">📊</div>
                  <p className="font-semibold">لا توجد دراسات</p>
                  <p className="text-sm text-gray-400 mt-1">لم يتم إنشاء أي دراسات بعد</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <div className="max-w-2xl space-y-6">
            {settingsSaved && (
              <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl text-sm font-semibold flex items-center gap-2 animate-fadeIn">
                ✅ تم حفظ الإعدادات بنجاح
              </div>
            )}

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-1 flex items-center gap-2">💰 إعدادات التسعير</h3>
              <p className="text-sm text-gray-500 mb-4">تحديد سعر الدراسة والعملة المستخدمة</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">سعر الدراسة</label>
                  <input
                    type="number"
                    value={settings.price}
                    onChange={e => setSettings({ ...settings, price: Number(e.target.value) })}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none bg-gray-50 focus:bg-white transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">العملة</label>
                  <input
                    type="text"
                    value={settings.currency}
                    onChange={e => setSettings({ ...settings, currency: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none bg-gray-50 focus:bg-white transition-colors"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-1 flex items-center gap-2">🏦 معلومات الدفع</h3>
              <p className="text-sm text-gray-500 mb-4">معلومات الدفع التي تظهر للمستخدمين</p>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">رقم الحساب البنكي (IBAN)</label>
                  <input
                    type="text"
                    value={settings.bankAccount}
                    onChange={e => setSettings({ ...settings, bankAccount: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none bg-gray-50 focus:bg-white transition-colors font-mono text-sm"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">رابط PayPal</label>
                  <input
                    type="text"
                    value={settings.paypalLink}
                    onChange={e => setSettings({ ...settings, paypalLink: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none bg-gray-50 focus:bg-white transition-colors text-sm"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">رقم فودافون كاش / محفظة إلكترونية</label>
                  <input
                    type="text"
                    value={settings.vodafoneCash}
                    onChange={e => setSettings({ ...settings, vodafoneCash: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none bg-gray-50 focus:bg-white transition-colors text-sm"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">تعليمات الدفع</label>
                  <textarea
                    value={settings.instructions}
                    onChange={e => setSettings({ ...settings, instructions: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none resize-none bg-gray-50 focus:bg-white transition-colors"
                    rows={3}
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleSaveSettings}
              className="px-8 py-3 bg-gradient-to-l from-[#1E3A8A] to-blue-700 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 hover:-translate-y-0.5 flex items-center gap-2"
            >
              💾 حفظ الإعدادات
            </button>
          </div>
        )}
      </main>

      {/* Receipt Modal */}
      {showReceipt && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn" onClick={() => setShowReceipt(null)}>
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full animate-scaleIn shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold">🧾 إثبات الدفع</h3>
              <button onClick={() => setShowReceipt(null)} className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-gray-200 transition-colors">✕</button>
            </div>
            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-8 text-center border border-gray-200">
              <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-3">🧾</div>
              <p className="text-sm font-semibold text-gray-700">تم رفع إيصال الدفع بنجاح</p>
              <p className="text-xs text-gray-400 mt-2 break-all font-mono bg-white p-2 rounded-lg mt-3">{showReceipt}</p>
            </div>
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showStudyReport && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn" onClick={() => setShowStudyReport(null)}>
          <div className="bg-white rounded-2xl p-6 max-w-3xl w-full max-h-[80vh] overflow-y-auto animate-scaleIn shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4 sticky top-0 bg-white pb-2 border-b border-gray-100">
              <h3 className="text-lg font-bold">📄 التقرير</h3>
              <button onClick={() => setShowStudyReport(null)} className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-gray-200 transition-colors">✕</button>
            </div>
            <pre className="whitespace-pre-wrap text-sm text-gray-700 leading-relaxed font-[Cairo]">{showStudyReport}</pre>
          </div>
        </div>
      )}
    </div>
  );
}
