import { useState } from 'react';
import { User } from '../types';
import { getPaymentSettings, updateUserReceipt } from '../store';

interface Props {
  user: User;
  onComplete: () => void;
  onBack: () => void;
}

export default function PaymentPage({ user, onComplete, onBack }: Props) {
  const settings = getPaymentSettings();
  const [uploaded, setUploaded] = useState(false);
  const [fileName, setFileName] = useState('');
  const [dragActive, setDragActive] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const processFile = (file: File) => {
    setFileName(file.name);
    // Simulate file upload - in production this would upload to a server
    const fakeUrl = `receipt_${user.id}_${Date.now()}_${file.name}`;
    updateUserReceipt(user.id, fakeUrl);
    setUploaded(true);
    setTimeout(() => {
      onComplete();
    }, 2500);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else if (e.type === 'dragleave') setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const paymentMethods = [
    { icon: '🏦', title: 'تحويل بنكي', value: settings.bankAccount, label: 'رقم الحساب (IBAN)' },
    { icon: '💸', title: 'PayPal', value: settings.paypalLink, label: 'رابط الدفع' },
    { icon: '📱', title: 'فودافون كاش', value: settings.vodafoneCash, label: 'رقم المحفظة' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-bl from-[#1E3A8A] via-blue-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <button onClick={onBack} className="text-blue-300 hover:text-white mb-4 inline-flex items-center gap-1 transition-colors text-sm font-semibold">
          <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          العودة للوحة التحكم
        </button>

        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden animate-scaleIn">
          {/* Header */}
          <div className="bg-gradient-to-l from-blue-600 via-blue-700 to-indigo-700 text-white p-8 text-center relative overflow-hidden">
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 left-0 w-40 h-40 bg-white rounded-full -translate-x-20 -translate-y-20" />
              <div className="absolute bottom-0 right-0 w-32 h-32 bg-white rounded-full translate-x-16 translate-y-16" />
            </div>
            <div className="relative z-10">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-4xl mx-auto mb-3 backdrop-blur-sm">💳</div>
              <h2 className="text-2xl font-black mb-1">تفعيل الحساب</h2>
              <p className="text-blue-200 text-sm">ادفع لتتمكن من إنشاء دراسات الجدوى الاحترافية</p>
            </div>
          </div>

          <div className="p-6">
            {/* Price */}
            <div className="bg-gradient-to-l from-blue-50 to-indigo-50 rounded-2xl p-6 text-center mb-6 border border-blue-100">
              <p className="text-sm text-blue-600 font-semibold mb-2">سعر الدراسة الواحدة</p>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-6xl font-black text-[#1E3A8A]">{settings.price}</span>
                <span className="text-xl font-bold text-blue-500">{settings.currency}</span>
              </div>
            </div>

            {/* Payment Methods */}
            <div className="space-y-3 mb-6">
              <h3 className="font-bold text-gray-900 text-sm mb-3 flex items-center gap-2">
                <span className="w-1 h-4 bg-[#1E3A8A] rounded-full" />
                طرق الدفع المتاحة
              </h3>
              
              {paymentMethods.map((method, i) => (
                <div key={i} className="bg-gray-50 hover:bg-gray-100 rounded-xl p-4 flex items-center gap-3 transition-colors border border-gray-100 group">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-xl shadow-sm group-hover:shadow-md transition-shadow">
                    {method.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-gray-800">{method.title}</p>
                    <p className="text-xs text-gray-500 truncate font-mono" dir="ltr">{method.value}</p>
                  </div>
                  <button
                    onClick={() => navigator.clipboard?.writeText(method.value)}
                    className="px-2 py-1 text-xs text-blue-600 hover:bg-blue-100 rounded-lg transition-colors font-semibold"
                  >
                    نسخ
                  </button>
                </div>
              ))}
            </div>

            {/* Instructions */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
              <div className="flex items-start gap-2">
                <span className="text-lg">📌</span>
                <p className="text-sm text-amber-800 leading-relaxed">{settings.instructions}</p>
              </div>
            </div>

            {/* Upload */}
            {!uploaded ? (
              <div
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <label className="block w-full cursor-pointer">
                  <div className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 ${
                    dragActive 
                      ? 'border-blue-500 bg-blue-50 scale-[1.02]' 
                      : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50/50'
                  }`}>
                    <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-3">📤</div>
                    <p className="font-bold text-gray-900 mb-1">رفع إثبات الدفع</p>
                    <p className="text-sm text-gray-500">اسحب الملف هنا أو اضغط للاختيار</p>
                    <div className="flex items-center justify-center gap-2 mt-3">
                      {['JPG', 'PNG', 'PDF'].map(ext => (
                        <span key={ext} className="px-2 py-0.5 bg-gray-100 text-gray-500 rounded text-xs font-mono">{ext}</span>
                      ))}
                    </div>
                  </div>
                  <input
                    type="file"
                    accept=".jpg,.jpeg,.png,.pdf"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </div>
            ) : (
              <div className="bg-green-50 border border-green-200 rounded-2xl p-6 text-center animate-scaleIn">
                <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-3">
                  <span className="animate-pulse">✅</span>
                </div>
                <p className="font-bold text-green-800 mb-1">تم رفع الإيصال بنجاح!</p>
                <p className="text-sm text-green-600 font-mono">{fileName}</p>
                <div className="mt-4 flex items-center justify-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <p className="text-xs text-green-500">جاري التحويل لصفحة الانتظار...</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
